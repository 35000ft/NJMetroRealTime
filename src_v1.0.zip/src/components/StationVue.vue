<template>
    <div>

    </div>
</template>
<script>
export default {
    name: 'StationVue',
    components: {

    },
    mixins: [],
    props: {

    },
    data() {
        return {

        }
    },
    computed: {

    },
    watch: {

    },
    mounted() {

    },
    methods: {

    }
};
</script>
<style lang='' scoped>
</style>