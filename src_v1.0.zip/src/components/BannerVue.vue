<template>
    <div>

    </div>
</template>
<script>
export default {
    name: 'BannerVue',
    components: {

    },
    mixins: [],
    props: {

    },
    data() {
        return {

        }
    },
    computed: {

    },
    watch: {

    },
    mounted() {

    },
    methods: {

    }
};
</script>
<style lang='' scoped>
</style>